# sensehat_sensors
RaspberryPi mounted SenseHat's measuring functions as Python object
